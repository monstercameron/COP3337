package things;

public class Names {

    public static final String[] lastNames = {"Smith", "Johnson", "Williams", "Brown",
                                            "Jones", "Garcia", "Miller", "Davis",
                                            "Rodriguez", "Martinez", "Hernandez",
                                            "Lopez", "Gonzalez", "Wilson", "Anderson",
                                            "Thomas", "Taylor", "Moore", "Jackson",
                                            "Martin", "lee", "Perez"};

    public static final String[] firstNames =  { "James", "Robert", "John", "Michael",
                                            "David", "William", "Richard", "Joseph",
                                            "Thomas", "Charles", "Christopher", "Mary",
                                            "Patricia", "Jennifer", "Linda", "Elizabeth",
                                            "Barbara", "Susan", "Jessica", "Sarah",
                                            "Karen", "Lisa"};
}
